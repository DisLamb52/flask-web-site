from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3
import json
import random
from functools import wraps
import os
import re
from datetime import datetime
from database import *

app = Flask(__name__)
app.secret_key = os.urandom(24)
app.config['CACHE_TYPE'] = 'simple'
app.config['CACHE_DEFAULT_TIMEOUT'] = 300

def load_questions():
    with open('questions.json', 'r', encoding='utf-8') as f:
        questions = json.load(f)
    return questions

def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Будь ласка, увійдіть для доступу до цієї сторінки', 'warning')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

@app.route('/')
def index():
    return render_template('index.html', logged_in='user_id' in session)

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        first_name = request.form['first_name']
        group_number = request.form['group_number']
        password = request.form['password']
        
        if not re.match(r'^\w{3,20}$', username):
            flash('Логін повинен містити 3-20 символів (літери, цифри, _)', 'danger')
            return redirect(url_for('register'))
        
        if not re.match(r'^[А-Я]{2}\s\d{2,}-[а-я]$', group_number):
            flash('Невірний формат номеру групи', 'danger')
            return redirect(url_for('register'))
        
        conn = sqlite3.connect('users.db')
        c = conn.cursor()
        c.execute("SELECT * FROM users WHERE username=?", (username,))
        if c.fetchone():
            flash('Користувач з таким логіном вже існує', 'danger')
            conn.close()
            return redirect(url_for('register'))
        conn.close()
        
        add_user(username, first_name, group_number, password)
        flash('Реєстрація успішна! Тепер ви можете увійти.', 'success')
        return redirect(url_for('login'))
    
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        user = get_user_by_credentials(username, password)
        if user:
            session['user_id'] = user['id']
            session['username'] = user['username']
            session['user_name'] = user['first_name']
            flash('Ви успішно увійшли!', 'success')
            return redirect(url_for('profile'))
        else:
            flash('Невірний логін або пароль', 'danger')
    
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    session.clear()
    flash('Ви вийшли з акаунту', 'info')
    return redirect(url_for('index'))

@app.route('/profile', methods=['GET', 'POST'])
@login_required
def profile():
    if request.method == 'POST':
        username = request.form['username']
        first_name = request.form['first_name']
        group_number = request.form['group_number']
        password = request.form.get('password')

        if not re.match(r'^\w{3,20}$', username):
            flash('Невірний формат логіна', 'danger')
            return redirect(url_for('profile'))

        if not re.match(r'^[А-Я]{2}\s\d{2,}-[а-я]$', group_number):
            flash('Невірний формат номеру групи', 'danger')
            return redirect(url_for('profile'))

        success = update_user(session['user_id'], username, first_name, group_number, password)

        if success:
            session['username'] = username
            flash('Профіль оновлено!', 'success')
        else:
            flash('Цей логін вже зайнятий', 'danger')
        
        return redirect(url_for('profile'))
    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    c.execute("SELECT username, first_name, group_number, score FROM users WHERE id=?", (session['user_id'],))
    user = c.fetchone()
    conn.close()

    if not user:
        flash('Помилка завантаження профілю', 'danger')
        return redirect(url_for('index'))

    return render_template('profile.html', username=user[0], first_name=user[1], group_number=user[2], score=user[3])


@app.route('/delete_account', methods=['POST'])
@login_required
def delete_account():
    delete_user(session['user_id'])
    session.clear()
    flash('Ваш акаунт було видалено', 'info')
    return redirect(url_for('index'))

@app.route('/test', methods=['GET', 'POST'])
@login_required
def test():
    questions = load_questions()
    
    if request.method == 'POST':
        score = 0
        incorrect_answers = []
        
        for question in questions:
            q_id = question['id']
            user_answer = request.form.get(f'q{q_id}')
            correct_answer = question['correct']
            
            if user_answer and int(user_answer) == correct_answer:
                score += 1
            else:
                incorrect_answers.append({
                    'question': question['question'],
                    'correct_option': question['options'][correct_answer],
                    'explanation': question.get('explanation', 'Немає додаткового пояснення')
                })
        
        update_user_score(session['user_id'], score)
        
        return render_template('result.html', 
                            score=score, 
                            total=len(questions),
                            incorrect_answers=incorrect_answers)
    
    shuffled_questions = random.sample(questions, len(questions))
    for question in shuffled_questions:
        options = question['options']
        correct_index = question['correct']
        
        correct_answer = options[correct_index]
        
        random.shuffle(options)
        
        question['correct'] = options.index(correct_answer)
    
    return render_template('test.html', questions=shuffled_questions)

@app.route('/about')
def about():
    return render_template('about.html')

if __name__ == '__main__':
    init_db()
    app.run(debug=True)