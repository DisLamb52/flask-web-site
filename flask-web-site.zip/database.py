import sqlite3
from werkzeug.security import generate_password_hash, check_password_hash

def init_db():
    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    
    c.execute('''CREATE TABLE IF NOT EXISTS users
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  username TEXT UNIQUE NOT NULL,
                  first_name TEXT NOT NULL,
                  group_number TEXT NOT NULL,
                  password TEXT NOT NULL,
                  score INTEGER DEFAULT 0)''')
    
    c.execute('''CREATE TABLE IF NOT EXISTS test_results
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  user_id INTEGER,
                  score INTEGER,
                  timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                  FOREIGN KEY(user_id) REFERENCES users(id))''')
    
    conn.commit()
    conn.close()

def add_user(username, first_name, group_number, password):
    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    hashed_password = generate_password_hash(password)
    c.execute("INSERT INTO users (username, first_name, group_number, password) VALUES (?, ?, ?, ?)",
              (username, first_name, group_number, hashed_password))
    conn.commit()
    conn.close()

def get_user_by_credentials(username, password):
    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    c.execute("SELECT * FROM users WHERE username=?", (username,))
    user = c.fetchone()
    conn.close()
    
    if user and check_password_hash(user[4], password):
        return {
            'id': user[0],
            'username': user[1],
            'first_name': user[2],
            'group_number': user[3],
            'score': user[5]
        }
    return None

def update_user(user_id, username, first_name, group_number, password=None):
    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    
    c.execute("SELECT id FROM users WHERE username = ? AND id != ?", (username, user_id))
    if c.fetchone():
        conn.close()
        return False
    
    if password:
        hashed_password = generate_password_hash(password)
        c.execute("""UPDATE users SET 
                    username = ?, 
                    first_name = ?, 
                    group_number = ?,
                    password = ?
                    WHERE id = ?""",
                (username, first_name, group_number, hashed_password, user_id))
    else:
        c.execute("""UPDATE users SET 
                    username = ?, 
                    first_name = ?, 
                    group_number = ?
                    WHERE id = ?""",
                (username, first_name, group_number, user_id))
    
    conn.commit()
    conn.close()
    return True

def delete_user(user_id):
    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    c.execute("DELETE FROM users WHERE id=?", (user_id,))
    conn.commit()
    conn.close()

def update_user_score(user_id, score):
    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    c.execute("UPDATE users SET score=? WHERE id=?", (score, user_id))
    c.execute("INSERT INTO test_results (user_id, score) VALUES (?, ?)", (user_id, score))
    conn.commit()
    conn.close()

def get_user_results(user_id):
    conn = sqlite3.connect('users.db')
    c = conn.cursor()
    c.execute("SELECT score, timestamp FROM test_results WHERE user_id=? ORDER BY timestamp DESC", (user_id,))
    results = c.fetchall()
    conn.close()
    return results