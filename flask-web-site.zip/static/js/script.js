document.addEventListener('DOMContentLoaded', function() {
    const animateOnScroll = function() {
        const elements = document.querySelectorAll('.question-card, .card, .alert');
        
        elements.forEach(element => {
            const elementPosition = element.getBoundingClientRect().top;
            const screenPosition = window.innerHeight / 1.3;
            
            if (elementPosition < screenPosition) {
                element.classList.add('animate__fadeInUp');
            }
        });
    };
    
    window.addEventListener('scroll', animateOnScroll);
    animateOnScroll();
    
    const questionCards = document.querySelectorAll('.question-card');
    questionCards.forEach(card => {
        const questionText = card.querySelector('.card-title').textContent;
        
        const hintButton = document.createElement('button');
        hintButton.className = 'btn btn-sm btn-outline-info hint-button';
        hintButton.innerHTML = '<i class="bi bi-lightbulb"></i> Підказка';
        
        const cardBody = card.querySelector('.card-body');
        cardBody.appendChild(hintButton);
        
        hintButton.addEventListener('click', function() {
            alert('Підказка: ' + questionText);
        });
    });
    
    const testForm = document.querySelector('form[action="/test"]');
    if (testForm) {
        testForm.addEventListener('submit', function(e) {
            const unanswered = document.querySelectorAll('input[type="radio"]:checked').length < 15;
            if (unanswered) {
                if (!confirm('Ви відповіли не на всі питання. Продовжити?')) {
                    e.preventDefault();
                }
            }
        });
    }
});